//
//  main.swift
//  IntegerFloatAndTypeSafety
//
//  Created by anil kumar giri on 21/02/16.
//  Copyright © 2016 AKG. All rights reserved.
//

import Foundation

//Integer Boundes
let minSizeOfInt=Int.min
let maxSizeOfInt=Int.max
print(minSizeOfInt) //output would be machine word length min size
print(maxSizeOfInt) //output would be machine word length max size

let minSizeOfUInt=UInt.min //output would be 0
let maxSizeOfUInt=UInt.max // output would be machine word length max size in unsigned category
print(minSizeOfUInt)
print(maxSizeOfInt)

//  Signed Integer sizes for 8,16,32 and 64.
let minSizeOfInt8=Int8.min
let maxSizeOfInt8=Int8.max

print(minSizeOfInt8)
print(maxSizeOfInt8)

let minSizeOfInt16=Int16.min
let maxSizeOfInt16=Int16.max

print(minSizeOfInt16)
print(maxSizeOfInt16)

let minSizeOfInt32=Int32.min
let maxSizeOfInt32=Int32.max

print(minSizeOfInt32)
print(maxSizeOfInt32)

let minSizeOfInt64=Int64.min
let maxSizeOfInt64=Int64.max

print(minSizeOfInt64)
print(maxSizeOfInt64)

//  unsigned Integer sizes for 8,16,32 and 64.
let minSizeOfUInt8=UInt8.min
let maxSizeOfUInt8=UInt8.max

print(minSizeOfUInt8)
print(maxSizeOfUInt8)

let minSizeOfUInt16=UInt16.min
let maxSizeOfUInt16=UInt16.max

print(minSizeOfInt16)
print(maxSizeOfInt16)

let minSizeOfUInt32=UInt32.min
let maxSizeOfUInt32=UInt32.max

print(minSizeOfUInt32)
print(maxSizeOfUInt32)

let minSizeOfUInt64=UInt64.min
let maxSizeOfUInt64=UInt64.max

print(minSizeOfUInt64)
print(maxSizeOfUInt64)

let z=3
let n=3.456
let x=Double(z) + n

var x12: UInt16=34
var p1: UInt8=3
var zz=x12 + UInt16(p1)

//Type conversion example (Constant and Variables)

var t=2
var s=3.45
var ll=s+Double(t)
print(ll)

//Here type conversion is not required as these are numarical constant
var lll=3 + 0.4567
print(lll)  // It works 

